$(document).ready(function(){
	Header.init();
	Carousel.init();
	Details.init();
});
