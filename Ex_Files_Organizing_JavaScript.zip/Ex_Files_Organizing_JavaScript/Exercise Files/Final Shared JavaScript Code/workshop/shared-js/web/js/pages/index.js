(function(context){

	function init(){}

	function teardown(){}

	Pages.page_scripts["/index"] = {
		init: init,
		teardown: teardown
	};

})(window);
